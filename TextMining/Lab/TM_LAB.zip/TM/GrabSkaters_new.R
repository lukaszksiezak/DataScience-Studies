library(httr)
#-----------------------------------------------------------------------
# Create a function that will take a year and return a dataframe
#-----------------------------------------------------------------------
GrabSkaters <- function(S) {
  # The function takes parameter S which is a string and represents the Season
  # Returns: data frame
  ## create the URL
  URL <- GET(paste("http://www.hockey-reference.com/leagues/NHL_", 
                   S, "_skaters.html", sep=""))
  
  ## grab the page -- the table is parsed nicely
  tables <- readHTMLTable(rawToChar(URL$content))
  ds.skaters <- tables$stats
  
  ## I don't like dealing with factors if I don't have to
  ## and I prefer lower case
  for(i in 1:ncol(ds.skaters)) {
    ds.skaters[,i] <- as.character(ds.skaters[,i])
    names(ds.skaters) <- tolower(colnames(ds.skaters))
  }
  
  ## finally fix the columns - NAs forced by coercion warnings
  for(i in c(1, 3, 6:18)) {
    ds.skaters[,i] <- as.numeric(ds.skaters[, i])
  }
  
  ## add the year
  ds.skaters$season <- S
  ## return the dataframe
  return(ds.skaters)
}
GrabSkaters("2014")
